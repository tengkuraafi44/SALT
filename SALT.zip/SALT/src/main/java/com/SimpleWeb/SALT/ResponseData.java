package com.SimpleWeb.SALT;

public interface ResponseData {
}
