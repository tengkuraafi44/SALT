package com.SimpleWeb.SALT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaltApplicationTests {

	@Test
	void contextLoads() {
	}

}
